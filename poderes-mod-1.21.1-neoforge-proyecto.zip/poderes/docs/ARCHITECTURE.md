# Poderes — Diseño del sistema

## 1. Requisitos
**Funcionales**
- Varios *poderes*, cada uno con varias *habilidades* (ej. Telequinesis: sujetar mobs, lanzar, rayo psíquico…).
- Todos los poderes deben poder **craftearse en survival**.
- Minecraft Java 1.21.1, NeoForge 21.1.x.

**No funcionales**
- Añadir un poder/habilidad nuevo debe costar pocas líneas (extensibilidad).
- Cero dependencias externas: un único `.jar`.
- Servidor autoritativo: toda la lógica corre en el servidor; el cliente solo renderiza.
- Sin código de red propio (menos superficie de bugs).

**Restricciones**: Java 21, 1.21.1 (carpeta `recipe/` en singular, componentes de ítem en vez de NBT).

## 2. Diseño de alto nivel
```
 Jugador (clic derecho / agachado+clic)
        │
        ▼
 PowerStaffItem.use()            ← único punto de entrada
   ├─ shift  → cambia habilidad  (CUSTOM_DATA: "ability")
   ├─ cooldown por habilidad     (CUSTOM_DATA: "cd<i>" = gameTime de listo)
   └─ Ability.exec().run(level, player)
              │
              ▼
        Powers.java  (26 habilidades, funciones puras sobre ServerLevel/ServerPlayer)
              │ usan
              ▼
   Fx (daño, objetivos, partículas)   Rays (raycast de mirada)
              │
              └─ TelekinesisHold  ← único estado persistente en memoria
                    (ServerTickEvent.Post mueve mobs sujetados)
```
Modelo de datos:
- `Power(id, color, List<Ability>)` y `Ability(id, cooldown, durabilidad, Executor)` son **datos inmutables**.
- Estado por bastón → **componente `CUSTOM_DATA` del ItemStack** (viaja con el ítem, se guarda solo, sin registrar tipos).
- Estado por jugador → solo `TelekinesisHold` (Map<UUID, Hold>, volátil: se pierde al reiniciar, lo cual es deseable).

## 3. ADR-001: Un bastón por poder, habilidades seleccionables por ciclo

**Status:** Accepted

**Contexto.** Hay 26 habilidades. Hace falta un modo de elegirlas, que sea craftable y no sature el juego con 26 ítems o teclas.

| Opción | Complejidad | Pros | Contras |
|---|---|---|---|
| A. 1 ítem por habilidad (26 ítems) | Baja | Trivial | Inventario saturado, 26 recetas/texturas |
| **B. 1 bastón por poder + ciclar habilidad (elegida)** | Media | 6 ítems; la "variedad por poder" es la mecánica central; sin red | Hay que ciclar |
| C. Keybinds + paquetes de red + capability de jugador | Alta | Habilidades instantáneas sin ciclar | Cliente+red+sincronización, mucho más código y riesgo |

**Decisión.** Opción B. Agachado + clic derecho cicla; clic derecho usa.

**Consecuencias.** Más fácil: añadir habilidades (1 método + 1 línea + lang). Más difícil: combos rápidos entre habilidades. A revisar: si se quieren hotkeys, migrar a C reutilizando `Ability` tal cual (el ejecutor ya es independiente del ítem).

## 4. ADR-002: Cooldowns y estado en el ItemStack (no en el jugador)

**Status:** Accepted. Evita attachments/capabilities/sincronización. Contra: un cooldown "viaja" con el ítem (soltarlo y recogerlo no lo resetea, lo cual es correcto). No se usa `ItemCooldowns` porque bloquearía también el cambio de habilidad (el juego no llama a `use()` durante un cooldown de ítem).

## 5. ADR-003: Habilidades "hitscan" en vez de entidades proyectil

**Status:** Accepted. Rayos, bolas de fuego, dardos de hielo se resuelven con raycast + partículas.
Evita registrar `EntityType`s, renderers y sincronización cliente; reduce el riesgo de incompatibilidades entre versiones. Contra: no hay proyectiles visibles viajando. Revisar si se quiere más espectáculo visual.

## 6. Balance y seguridad
- Cada bastón tiene **600 de durabilidad**; cada habilidad gasta 1–6. Se repara con amatista en yunque.
- Las habilidades ofensivas **no afectan a jugadores, mascotas propias ni armor stands** (`Fx.isTarget`).
- Ninguna habilidad rompe bloques (la bola de fuego no usa explosión de mundo; el muro es hielo escarchado que se derrite).
- Rayo cae mínimo a 4 bloques de ti.

## 7. Qué revisaría al crecer
1. Hotkeys/GUI de selección (ADR-001, opción C).
2. Maná o recurso compartido en vez de solo durabilidad.
3. Configuración (`ModConfigSpec`) para daños/cooldowns.
4. Datagen para recetas/lang/modelos en vez de JSON a mano.
5. Proyectiles reales con `EntityType` propio.
