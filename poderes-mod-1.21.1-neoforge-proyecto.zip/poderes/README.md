# Poderes (Minecraft 1.21.1 · NeoForge)

Mod de **6 poderes** con **26 habilidades**. Cada poder es un **bastón crafteable en survival**.

## Uso
- **Clic derecho**: usa la habilidad seleccionada.
- **Agachado + clic derecho**: cambia de habilidad (se muestra en la action bar y en el tooltip).
- Cada habilidad tiene su propio cooldown y gasta durabilidad. Repara el bastón con **fragmentos de amatista** en un yunque.

## Poderes y habilidades
| Poder | Habilidades |
|---|---|
| **Telequinesis** | Sujetar (levanta un mob y lo mueve con tu mirada), Lanzar, Rayo psíquico, Onda de choque, Ascenso |
| **Piroquinesis** | Bola de fuego, Anillo de fuego, Lanzallamas, Piel ígnea |
| **Criokinesis** | Dardo helado, Nova helada, Muro de hielo, Armadura de hielo |
| **Tormenta** | Rayo, Cadena eléctrica, Tormenta eléctrica, Impulso estático |
| **Sombra** | Parpadeo (teletransporte), Drenaje vital, Oscuridad, Manto de sombras |
| **Naturaleza** | Curación, Raíces, Florecer (bonemeal en área), Salto de gigante, Piel de corteza |

## Crafteo (mesa de crafteo, todos iguales salvo el centro-superior)
```
 [C]          C = catalizador del poder
[A][D][A]     A = fragmento de amatista, D = diamante
 [ ][S][ ]    S = vara de blaze
```
| Bastón | Catalizador (C) |
|---|---|
| Telequinesis | Ojo de ender |
| Piroquinesis | Carga de fuego |
| Criokinesis | Hielo azul |
| Tormenta | Pararrayos |
| Sombra | Obsidiana llorona |
| Naturaleza | Manzana de oro |

## Compilar el .jar
El mod **no tiene dependencias externas**: el `.jar` de `build/libs/` es autosuficiente. Requiere **Java 21**.

**Opción 1 — Gradle instalado (8.8+):**
```
gradle build
```
**Opción 2 — Wrapper:** `gradle wrapper --gradle-version 8.10.2` una vez, luego `./gradlew build`.

**Opción 3 — Sin instalar nada (GitHub):** sube esta carpeta a un repositorio; la acción `.github/workflows/build.yml` compila y publica el `.jar` como artefacto (pestaña *Actions*).

**Opción 4 — IntelliJ IDEA:** abre la carpeta como proyecto Gradle y ejecuta la tarea `build`.

Resultado: `build/libs/poderes-1.21.1-1.0.0.jar` → cópialo a la carpeta `mods/` de NeoForge 1.21.1 (cliente y servidor).

> Si Gradle no encuentra `net.neoforged.moddev` 2.0.78 o NeoForge `21.1.172`, cambia esas dos versiones en `build.gradle` por las del MDK oficial de NeoForge 1.21.1.

## Añadir un poder o habilidad
Ver `docs/ARCHITECTURE.md`. Resumen: una función en `Powers.java` + una línea en la lista de habilidades + clave en `lang/*.json`.
