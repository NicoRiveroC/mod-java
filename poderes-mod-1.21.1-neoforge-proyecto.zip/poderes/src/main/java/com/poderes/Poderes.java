package com.poderes;

import com.poderes.registry.ModItems;
import com.poderes.registry.ModTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(Poderes.MODID)
public class Poderes {
    public static final String MODID = "poderes";

    public Poderes(IEventBus modBus) {
        ModItems.ITEMS.register(modBus);
        ModTabs.TABS.register(modBus);
    }
}
