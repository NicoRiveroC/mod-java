package com.poderes.registry;

import com.poderes.Poderes;
import com.poderes.power.Powers;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Poderes.MODID);

    public static final Supplier<CreativeModeTab> MAIN = TABS.register("poderes", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.poderes"))
                    .icon(() -> new ItemStack(ModItems.STAFFS.get(Powers.TELEKINESIS).get()))
                    .displayItems((params, out) -> ModItems.STAFFS.values().forEach(s -> out.accept(s.get())))
                    .build());

    private ModTabs() {}
}
