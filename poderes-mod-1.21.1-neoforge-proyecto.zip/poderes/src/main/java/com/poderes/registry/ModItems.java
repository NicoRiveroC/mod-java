package com.poderes.registry;

import com.poderes.Poderes;
import com.poderes.item.PowerStaffItem;
import com.poderes.power.Power;
import com.poderes.power.Powers;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(Poderes.MODID);

    /** power -> bastón registrado */
    public static final Map<Power, Supplier<? extends Item>> STAFFS = new LinkedHashMap<>();

    static {
        for (Power power : Powers.ALL) {
            STAFFS.put(power, ITEMS.register("staff_" + power.id(),
                    () -> new PowerStaffItem(power, new Item.Properties().durability(600).rarity(Rarity.EPIC))));
        }
    }

    private ModItems() {}
}
