package com.poderes.power;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/** Una habilidad de un poder. El ejecutor devuelve true si se gastó (cooldown + durabilidad). */
public record Ability(String id, int cooldownTicks, int durabilityCost, Executor exec) {
    @FunctionalInterface
    public interface Executor {
        boolean run(ServerLevel level, ServerPlayer player);
    }
}
