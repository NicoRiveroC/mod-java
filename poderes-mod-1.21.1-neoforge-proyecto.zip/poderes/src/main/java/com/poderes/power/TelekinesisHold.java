package com.poderes.power;

import com.poderes.Poderes;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Estado servidor de "mobs sujetados" por telequinesis.
 * Cada tick de servidor mueve al mob hacia el punto que el jugador está mirando.
 */
@EventBusSubscriber(modid = Poderes.MODID)
public final class TelekinesisHold {
    private static final int MAX_TICKS = 200; // 10 s

    private static final class Hold {
        UUID target;
        double distance;
        int ticks = MAX_TICKS;
    }

    private static final Map<UUID, Hold> HOLDS = new HashMap<>();

    private TelekinesisHold() {}

    public static boolean isHolding(ServerPlayer p) {
        return HOLDS.containsKey(p.getUUID());
    }

    public static void start(ServerPlayer p, LivingEntity target) {
        Hold h = new Hold();
        h.target = target.getUUID();
        h.distance = Mth.clamp(p.distanceTo(target), 3.0, 12.0);
        HOLDS.put(p.getUUID(), h);
    }

    public static void release(ServerPlayer p) {
        HOLDS.remove(p.getUUID());
    }

    /** Suelta y devuelve el mob que sostenía el jugador (o null si no sostenía ninguno). */
    public static LivingEntity take(ServerLevel level, ServerPlayer p) {
        Hold h = HOLDS.remove(p.getUUID());
        if (h == null) return null;
        Entity e = level.getEntity(h.target);
        return (e instanceof LivingEntity le && le.isAlive()) ? le : null;
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (HOLDS.isEmpty()) return;
        MinecraftServer server = event.getServer();
        Iterator<Map.Entry<UUID, Hold>> it = HOLDS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Hold> en = it.next();
            Hold h = en.getValue();
            ServerPlayer p = server.getPlayerList().getPlayer(en.getKey());
            if (p == null || !p.isAlive() || --h.ticks <= 0) {
                it.remove();
                continue;
            }
            ServerLevel level = (ServerLevel) p.level();
            Entity t = level.getEntity(h.target);
            if (!(t instanceof LivingEntity) || !t.isAlive()) {
                it.remove();
                continue;
            }
            Vec3 want = p.getEyePosition().add(p.getLookAngle().scale(h.distance));
            Vec3 cur = t.position().add(0, t.getBbHeight() * 0.5, 0);
            t.setDeltaMovement(want.subtract(cur).scale(0.35));
            t.fallDistance = 0;
            t.hurtMarked = true;
            if (h.ticks % 4 == 0) {
                level.sendParticles(ParticleTypes.WITCH, cur.x, cur.y, cur.z, 2, 0.3, 0.3, 0.3, 0.0);
            }
        }
    }
}
