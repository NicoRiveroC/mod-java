package com.poderes.power;

import java.util.List;

/** Un poder = un bastón con varias habilidades. */
public record Power(String id, int color, List<Ability> abilities) {
}
