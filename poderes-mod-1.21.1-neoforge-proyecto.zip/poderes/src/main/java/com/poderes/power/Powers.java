package com.poderes.power;

import com.poderes.util.Fx;
import com.poderes.util.Rays;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Definición de todos los poderes y sus habilidades.
 * Para añadir un poder: crea un Power aquí, añádelo a ALL, y agrega receta, textura, modelo y lang.
 * Ability(id, cooldownTicks, durabilidadGastada, ejecutor)
 */
public final class Powers {
    private Powers() {}

    // ---------------------------------------------------------------- TELEQUINESIS
    public static final Power TELEKINESIS = new Power("telekinesis", 0xC084FC, List.of(
            new Ability("grab", 10, 1, Powers::grab),
            new Ability("launch", 40, 2, Powers::launch),
            new Ability("psychic_beam", 60, 2, Powers::psychicBeam),
            new Ability("shockwave", 200, 4, Powers::shockwave),
            new Ability("ascend", 160, 2, Powers::ascend)));

    // ---------------------------------------------------------------- PIROQUINESIS
    public static final Power PYROKINESIS = new Power("pyrokinesis", 0xFF6A1A, List.of(
            new Ability("fireball", 50, 2, Powers::fireball),
            new Ability("flame_ring", 160, 3, Powers::flameRing),
            new Ability("flamethrower", 80, 2, Powers::flamethrower),
            new Ability("fire_skin", 600, 4, Powers::fireSkin)));

    // ---------------------------------------------------------------- CRIOQUINESIS
    public static final Power CRYOKINESIS = new Power("cryokinesis", 0x6FD8FF, List.of(
            new Ability("frost_bolt", 50, 2, Powers::frostBolt),
            new Ability("frost_nova", 200, 3, Powers::frostNova),
            new Ability("ice_wall", 240, 3, Powers::iceWall),
            new Ability("ice_armor", 800, 4, Powers::iceArmor)));

    // ---------------------------------------------------------------- TORMENTA
    public static final Power STORM = new Power("storm", 0xFFE14D, List.of(
            new Ability("lightning", 100, 3, Powers::lightning),
            new Ability("chain", 100, 3, Powers::chain),
            new Ability("thunderstorm", 400, 6, Powers::thunderstorm),
            new Ability("static_dash", 120, 2, Powers::staticDash)));

    // ---------------------------------------------------------------- SOMBRA
    public static final Power SHADOW = new Power("shadow", 0x7A4DB8, List.of(
            new Ability("blink", 60, 2, Powers::blink),
            new Ability("drain", 100, 3, Powers::drain),
            new Ability("blind", 240, 3, Powers::blind),
            new Ability("cloak", 600, 4, Powers::cloak)));

    // ---------------------------------------------------------------- NATURALEZA
    public static final Power NATURE = new Power("nature", 0x5FD35F, List.of(
            new Ability("heal", 300, 4, Powers::heal),
            new Ability("roots", 200, 3, Powers::roots),
            new Ability("bloom", 120, 2, Powers::bloom),
            new Ability("leap", 100, 2, Powers::leap),
            new Ability("bark_skin", 700, 4, Powers::barkSkin)));

    public static final List<Power> ALL = List.of(TELEKINESIS, PYROKINESIS, CRYOKINESIS, STORM, SHADOW, NATURE);

    // =========================================================================================
    //  TELEQUINESIS
    // =========================================================================================

    /** Sujeta a un mob en el aire (sigue tu mirada hasta 10 s). Usar de nuevo = soltar. */
    private static boolean grab(ServerLevel l, ServerPlayer p) {
        if (TelekinesisHold.isHolding(p)) {
            TelekinesisHold.release(p);
            Fx.sound(l, p.position(), SoundEvents.ILLUSIONER_CAST_SPELL, 0.6f, 1.5f);
            return false; // soltar es gratis
        }
        EntityHitResult r = Rays.entity(p, 24);
        if (r == null) return Fx.fail(p, "no_target");
        LivingEntity t = (LivingEntity) r.getEntity();
        TelekinesisHold.start(p, t);
        Fx.sound(l, t.position(), SoundEvents.ILLUSIONER_CAST_SPELL, 0.8f, 0.8f);
        return true;
    }

    /** Lanza al mob sujetado (o al que apuntes) en la dirección de tu mirada. */
    private static boolean launch(ServerLevel l, ServerPlayer p) {
        LivingEntity t = TelekinesisHold.take(l, p);
        if (t == null) {
            EntityHitResult r = Rays.entity(p, 24);
            if (r == null) return Fx.fail(p, "no_target");
            t = (LivingEntity) r.getEntity();
        }
        Fx.push(t, p.getLookAngle().scale(2.8).add(0, 0.35, 0));
        Fx.magic(l, p, t, 4f);
        Fx.burst(l, ParticleTypes.CLOUD, t.position().add(0, t.getBbHeight() * 0.5, 0), 12, 0.3);
        Fx.sound(l, t.position(), SoundEvents.WARDEN_SONIC_BOOM, 0.4f, 1.6f);
        return true;
    }

    /** Rayo psíquico instantáneo: 8 de daño mágico a distancia. */
    private static boolean psychicBeam(ServerLevel l, ServerPlayer p) {
        EntityHitResult r = Rays.entity(p, 28);
        Vec3 to = r != null ? r.getLocation() : Rays.blockPoint(p, 28);
        Fx.line(l, Rays.muzzle(p), to, ParticleTypes.END_ROD);
        if (r != null) {
            LivingEntity t = (LivingEntity) r.getEntity();
            Fx.magic(l, p, t, 8f);
            Fx.burst(l, ParticleTypes.WITCH, to, 15, 0.3);
        }
        Fx.sound(l, p.position(), SoundEvents.ILLUSIONER_CAST_SPELL, 0.8f, 1.2f);
        return true;
    }

    /** Onda expansiva que empuja y daña a todo lo cercano. */
    private static boolean shockwave(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.position();
        for (LivingEntity e : Fx.targets(l, p, c, 8)) {
            Vec3 dir = e.position().subtract(c).multiply(1, 0, 1);
            dir = dir.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : dir.normalize();
            Fx.push(e, dir.scale(1.8).add(0, 0.6, 0));
            Fx.magic(l, p, e, 4f);
        }
        Fx.ring(l, ParticleTypes.CLOUD, c.add(0, 0.2, 0), 2, 24);
        Fx.ring(l, ParticleTypes.CLOUD, c.add(0, 0.2, 0), 5, 40);
        Fx.ring(l, ParticleTypes.CLOUD, c.add(0, 0.2, 0), 8, 56);
        Fx.sound(l, c, SoundEvents.WARDEN_SONIC_BOOM, 0.7f, 1.0f);
        return true;
    }

    /** Te impulsa hacia arriba y amortigua la caída. */
    private static boolean ascend(ServerLevel l, ServerPlayer p) {
        p.setDeltaMovement(p.getDeltaMovement().add(0, 1.3, 0));
        p.hurtMarked = true;
        p.fallDistance = 0;
        p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0));
        Fx.burst(l, ParticleTypes.CLOUD, p.position(), 20, 0.4);
        Fx.sound(l, p.position(), SoundEvents.ILLUSIONER_CAST_SPELL, 0.7f, 1.8f);
        return true;
    }

    // =========================================================================================
    //  PIROQUINESIS
    // =========================================================================================

    /** Bola de fuego instantánea: explota donde apuntas (no rompe bloques). */
    private static boolean fireball(ServerLevel l, ServerPlayer p) {
        EntityHitResult r = Rays.entity(p, 40);
        Vec3 hit = r != null ? r.getLocation() : Rays.blockPoint(p, 40);
        Fx.line(l, Rays.muzzle(p), hit, ParticleTypes.FLAME);
        l.sendParticles(ParticleTypes.EXPLOSION_EMITTER, hit.x, hit.y, hit.z, 1, 0, 0, 0, 0);
        Fx.sound(l, hit, SoundEvents.FIRECHARGE_USE, 1.0f, 0.8f);
        for (LivingEntity e : Fx.targets(l, p, hit, 4.0)) {
            Fx.magic(l, p, e, 8f);
            e.setRemainingFireTicks(120);
        }
        return true;
    }

    /** Anillo de fuego alrededor tuyo. */
    private static boolean flameRing(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.position();
        for (LivingEntity e : Fx.targets(l, p, c, 5.5)) {
            Fx.magic(l, p, e, 3f);
            e.setRemainingFireTicks(160);
            Vec3 dir = e.position().subtract(c).multiply(1, 0, 1);
            if (dir.lengthSqr() > 1.0E-4) Fx.push(e, dir.normalize().scale(0.8).add(0, 0.3, 0));
        }
        Fx.ring(l, ParticleTypes.FLAME, c.add(0, 0.3, 0), 5.5, 60);
        Fx.ring(l, ParticleTypes.FLAME, c.add(0, 0.8, 0), 4.0, 48);
        Fx.ring(l, ParticleTypes.SOUL_FIRE_FLAME, c.add(0, 0.3, 0), 2.5, 30);
        Fx.sound(l, c, SoundEvents.BLAZE_SHOOT, 1.0f, 0.7f);
        return true;
    }

    /** Cono de llamas frente a ti. */
    private static boolean flamethrower(ServerLevel l, ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        RandomSource rnd = l.getRandom();
        for (int i = 0; i < 40; i++) {
            Vec3 v = look.add(rnd.nextGaussian() * 0.12, rnd.nextGaussian() * 0.12, rnd.nextGaussian() * 0.12);
            Vec3 o = eye.add(look.scale(1.0)).subtract(0, 0.25, 0);
            l.sendParticles(ParticleTypes.FLAME, o.x, o.y, o.z, 0, v.x, v.y, v.z, 0.7); // count 0 = direccional
        }
        for (LivingEntity e : Fx.targets(l, p, p.position(), 10.5)) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            if (to.length() <= 10.5 && to.normalize().dot(look) > 0.82) {
                Fx.magic(l, p, e, 4f);
                e.setRemainingFireTicks(100);
            }
        }
        Fx.sound(l, p.position(), SoundEvents.BLAZE_SHOOT, 0.8f, 1.3f);
        return true;
    }

    /** Resistencia al fuego + fuerza durante unos segundos. */
    private static boolean fireSkin(ServerLevel l, ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 600, 0));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 300, 0));
        Fx.burst(l, ParticleTypes.FLAME, p.position().add(0, 1, 0), 40, 0.5);
        Fx.sound(l, p.position(), SoundEvents.FIRECHARGE_USE, 0.8f, 0.6f);
        return true;
    }

    // =========================================================================================
    //  CRIOQUINESIS
    // =========================================================================================

    /** Dardo helado: daño, lentitud fuerte y congelación. */
    private static boolean frostBolt(ServerLevel l, ServerPlayer p) {
        EntityHitResult r = Rays.entity(p, 30);
        Vec3 to = r != null ? r.getLocation() : Rays.blockPoint(p, 30);
        Fx.line(l, Rays.muzzle(p), to, ParticleTypes.SNOWFLAKE);
        if (r != null) {
            LivingEntity t = (LivingEntity) r.getEntity();
            Fx.magic(l, p, t, 5f);
            t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3));
            t.setTicksFrozen(300);
            Fx.burst(l, ParticleTypes.SNOWFLAKE, to, 25, 0.4);
        }
        Fx.sound(l, p.position(), SoundEvents.GLASS_BREAK, 0.6f, 1.8f);
        return true;
    }

    /** Nova helada: ralentiza y congela en área. */
    private static boolean frostNova(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.position();
        for (LivingEntity e : Fx.targets(l, p, c, 6)) {
            Fx.magic(l, p, e, 3f);
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 2));
            e.setTicksFrozen(200);
        }
        Fx.ring(l, ParticleTypes.SNOWFLAKE, c.add(0, 0.3, 0), 2, 24);
        Fx.ring(l, ParticleTypes.SNOWFLAKE, c.add(0, 0.3, 0), 4, 40);
        Fx.ring(l, ParticleTypes.SNOWFLAKE, c.add(0, 0.3, 0), 6, 56);
        Fx.sound(l, c, SoundEvents.GLASS_BREAK, 1.0f, 0.7f);
        return true;
    }

    /** Muro de hielo escarchado (5x3) delante de ti; se derrite solo. */
    private static boolean iceWall(ServerLevel l, ServerPlayer p) {
        Direction d = p.getDirection();
        Direction side = d.getClockWise();
        BlockPos base = p.blockPosition().relative(d, 3);
        int placed = 0;
        for (int w = -2; w <= 2; w++) {
            for (int h = 0; h <= 2; h++) {
                BlockPos pos = base.relative(side, w).above(h);
                if (l.getBlockState(pos).isAir()) {
                    l.setBlockAndUpdate(pos, Blocks.FROSTED_ICE.defaultBlockState());
                    l.scheduleTick(pos, Blocks.FROSTED_ICE, Mth.nextInt(l.getRandom(), 200, 400));
                    l.sendParticles(ParticleTypes.SNOWFLAKE, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                            4, 0.3, 0.3, 0.3, 0.01);
                    placed++;
                }
            }
        }
        if (placed == 0) return Fx.fail(p, "no_space");
        Fx.sound(l, Vec3.atCenterOf(base), SoundEvents.GLASS_BREAK, 1.0f, 0.5f);
        return true;
    }

    /** Resistencia + absorción durante 15 s. */
    private static boolean iceArmor(ServerLevel l, ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 1));
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 300, 1));
        Fx.burst(l, ParticleTypes.SNOWFLAKE, p.position().add(0, 1, 0), 40, 0.5);
        Fx.sound(l, p.position(), SoundEvents.GLASS_BREAK, 0.8f, 1.4f);
        return true;
    }

    // =========================================================================================
    //  TORMENTA
    // =========================================================================================

    private static void strike(ServerLevel l, ServerPlayer p, Vec3 pos) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(l);
        if (bolt == null) return;
        bolt.moveTo(pos.x, pos.y, pos.z);
        bolt.setCause(p);
        l.addFreshEntity(bolt);
    }

    /** Un rayo de verdad donde apuntas (mínimo 4 bloques de distancia para no electrocutarte). */
    private static boolean lightning(ServerLevel l, ServerPlayer p) {
        Vec3 hit = Rays.aimPoint(p, 48);
        if (hit.distanceTo(p.position()) < 4) return Fx.fail(p, "too_close");
        strike(l, p, hit);
        return true;
    }

    /** Descarga que salta entre hasta 5 mobs cercanos. */
    private static boolean chain(ServerLevel l, ServerPlayer p) {
        EntityHitResult r = Rays.entity(p, 24);
        if (r == null) return Fx.fail(p, "no_target");
        LivingEntity cur = (LivingEntity) r.getEntity();
        Set<UUID> seen = new HashSet<>();
        seen.add(cur.getUUID());
        Vec3 prev = Rays.muzzle(p);
        float dmg = 8f;
        for (int i = 0; i < 5 && cur != null; i++) {
            Vec3 pos = cur.getBoundingBox().getCenter();
            Fx.line(l, prev, pos, ParticleTypes.ELECTRIC_SPARK);
            Fx.burst(l, ParticleTypes.ELECTRIC_SPARK, pos, 12, 0.3);
            Fx.magic(l, p, cur, dmg);
            prev = pos;
            dmg = 6f;
            LivingEntity next = null;
            double best = 49; // 7 bloques^2
            for (LivingEntity e : Fx.targets(l, p, pos, 7)) {
                if (seen.contains(e.getUUID())) continue;
                double d = e.distanceToSqr(cur);
                if (d < best) {
                    best = d;
                    next = e;
                }
            }
            if (next != null) seen.add(next.getUUID());
            cur = next;
        }
        Fx.sound(l, p.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.4f, 2.0f);
        return true;
    }

    /** Hasta 6 rayos alrededor del punto apuntado. */
    private static boolean thunderstorm(ServerLevel l, ServerPlayer p) {
        Vec3 c = Rays.aimPoint(p, 32);
        RandomSource rnd = l.getRandom();
        int placed = 0;
        for (int i = 0; i < 14 && placed < 6; i++) {
            double a = rnd.nextDouble() * Math.PI * 2;
            double dist = 2 + rnd.nextDouble() * 7;
            BlockPos ground = l.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    BlockPos.containing(c.x + Math.cos(a) * dist, c.y, c.z + Math.sin(a) * dist));
            Vec3 pos = Vec3.atBottomCenterOf(ground);
            if (pos.distanceTo(p.position()) < 5) continue;
            strike(l, p, pos);
            placed++;
        }
        return placed > 0 || Fx.fail(p, "too_close");
    }

    /** Dash eléctrico hacia donde miras + velocidad. */
    private static boolean staticDash(ServerLevel l, ServerPlayer p) {
        Vec3 from = p.position().add(0, 1, 0);
        p.setDeltaMovement(p.getLookAngle().scale(2.2));
        p.hurtMarked = true;
        p.fallDistance = 0;
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 1));
        Fx.burst(l, ParticleTypes.ELECTRIC_SPARK, from, 40, 0.6);
        Fx.sound(l, p.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.3f, 2.0f);
        return true;
    }

    // =========================================================================================
    //  SOMBRA
    // =========================================================================================

    /** Teletransporte corto (16 bloques) hacia donde miras. */
    private static boolean blink(ServerLevel l, ServerPlayer p) {
        Vec3 look = p.getLookAngle();
        Vec3 end = Rays.blockPoint(p, 16).subtract(look.scale(0.6));
        Vec3 feet = end.subtract(0, p.getEyeHeight(), 0);
        AABB box = p.getBoundingBox().move(feet.subtract(p.position()));
        for (int i = 0; i < 4 && !l.noCollision(p, box); i++) {
            box = box.move(0, 0.5, 0);
            feet = feet.add(0, 0.5, 0);
        }
        if (!l.noCollision(p, box)) return Fx.fail(p, "no_space");
        Fx.burst(l, ParticleTypes.PORTAL, p.position().add(0, 1, 0), 30, 0.4);
        p.connection.teleport(feet.x, feet.y, feet.z, p.getYRot(), p.getXRot());
        p.fallDistance = 0;
        Fx.burst(l, ParticleTypes.PORTAL, feet.add(0, 1, 0), 30, 0.4);
        Fx.sound(l, feet, SoundEvents.ENDERMAN_TELEPORT, 1.0f, 1.0f);
        return true;
    }

    /** Roba vida: 6 de daño al objetivo y te curas 3 (1,5 corazones). */
    private static boolean drain(ServerLevel l, ServerPlayer p) {
        EntityHitResult r = Rays.entity(p, 20);
        if (r == null) return Fx.fail(p, "no_target");
        LivingEntity t = (LivingEntity) r.getEntity();
        Fx.line(l, t.getBoundingBox().getCenter(), p.getEyePosition().subtract(0, 0.3, 0), ParticleTypes.SCULK_SOUL);
        Fx.magic(l, p, t, 6f);
        p.heal(3f);
        Fx.sound(l, t.position(), SoundEvents.ELDER_GUARDIAN_CURSE, 0.3f, 1.8f);
        return true;
    }

    /** Ciega y debilita a los enemigos cercanos. */
    private static boolean blind(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.position();
        List<LivingEntity> list = Fx.targets(l, p, c, 8);
        for (LivingEntity e : list) {
            e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 0));
            e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
        }
        Fx.ring(l, ParticleTypes.LARGE_SMOKE, c.add(0, 0.5, 0), 4, 30);
        Fx.ring(l, ParticleTypes.LARGE_SMOKE, c.add(0, 0.5, 0), 8, 50);
        Fx.sound(l, c, SoundEvents.ELDER_GUARDIAN_CURSE, 0.4f, 1.0f);
        return true;
    }

    /** Invisibilidad + velocidad durante 15 s. */
    private static boolean cloak(ServerLevel l, ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 300, 0));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 300, 0));
        Fx.burst(l, ParticleTypes.LARGE_SMOKE, p.position().add(0, 1, 0), 40, 0.5);
        Fx.sound(l, p.position(), SoundEvents.ENDERMAN_TELEPORT, 0.6f, 0.6f);
        return true;
    }

    // =========================================================================================
    //  NATURALEZA
    // =========================================================================================

    /** Te curas 8 (4 corazones) y curas 6 a jugadores y mascotas cercanas. */
    private static boolean heal(ServerLevel l, ServerPlayer p) {
        p.heal(8f);
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
        List<LivingEntity> allies = l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(6),
                e -> e != p && e.isAlive()
                        && (e instanceof Player || (e instanceof TamableAnimal t && t.isOwnedBy(p))));
        for (LivingEntity e : allies) {
            e.heal(6f);
            Fx.burst(l, ParticleTypes.HAPPY_VILLAGER, e.position().add(0, 1, 0), 12, 0.4);
        }
        Fx.ring(l, ParticleTypes.HAPPY_VILLAGER, p.position().add(0, 0.3, 0), 3, 30);
        Fx.burst(l, ParticleTypes.HAPPY_VILLAGER, p.position().add(0, 1, 0), 20, 0.5);
        Fx.sound(l, p.position(), SoundEvents.PLAYER_LEVELUP, 0.7f, 1.4f);
        return true;
    }

    /** Raíces: inmovilizan a los mobs cercanos 4 s. */
    private static boolean roots(ServerLevel l, ServerPlayer p) {
        List<LivingEntity> list = Fx.targets(l, p, p.position(), 6);
        if (list.isEmpty()) return Fx.fail(p, "no_target");
        for (LivingEntity e : list) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 6));
            Fx.magic(l, p, e, 2f);
            Fx.burst(l, ParticleTypes.COMPOSTER, e.position().add(0, 0.5, 0), 20, 0.4);
        }
        Fx.sound(l, p.position(), SoundEvents.ILLUSIONER_CAST_SPELL, 0.6f, 0.6f);
        return true;
    }

    /** Aplica bonemeal en área (radio 4) a cultivos, césped, saplings... */
    private static boolean bloom(ServerLevel l, ServerPlayer p) {
        ItemStack meal = new ItemStack(Items.BONE_MEAL, 64); // pila temporal, no consume tu inventario
        BlockPos c = p.blockPosition();
        int count = 0;
        outer:
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos pos = c.offset(dx, dy, dz);
                    if (BoneMealItem.applyBonemeal(meal, l, pos, p)) {
                        l.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 1.0,
                                pos.getZ() + 0.5, 4, 0.3, 0.2, 0.3, 0.0);
                        if (++count >= 24) break outer;
                    }
                }
            }
        }
        if (count == 0) return Fx.fail(p, "nothing_to_grow");
        Fx.sound(l, p.position(), SoundEvents.PLAYER_LEVELUP, 0.5f, 1.8f);
        return true;
    }

    /** Gran salto hacia adelante con caída suave. */
    private static boolean leap(ServerLevel l, ServerPlayer p) {
        Vec3 look = p.getLookAngle();
        p.setDeltaMovement(look.x * 1.0, 1.1, look.z * 1.0);
        p.hurtMarked = true;
        p.fallDistance = 0;
        p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 160, 0));
        Fx.burst(l, ParticleTypes.HAPPY_VILLAGER, p.position(), 20, 0.4);
        Fx.sound(l, p.position(), SoundEvents.ILLUSIONER_CAST_SPELL, 0.5f, 1.6f);
        return true;
    }

    /** Resistencia + regeneración II durante unos segundos. */
    private static boolean barkSkin(ServerLevel l, ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 400, 0));
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
        Fx.burst(l, ParticleTypes.COMPOSTER, p.position().add(0, 1, 0), 40, 0.5);
        Fx.sound(l, p.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 0.8f, 0.7f);
        return true;
    }
}
