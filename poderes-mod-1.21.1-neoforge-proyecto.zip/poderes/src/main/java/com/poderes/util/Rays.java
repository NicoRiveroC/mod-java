package com.poderes.util;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;


/** Raycasts desde la mirada del jugador. */
public final class Rays {
    private Rays() {}

    /** Punto desde donde "salen" los rayos visuales. */
    public static Vec3 muzzle(ServerPlayer p) {
        return p.getEyePosition().add(p.getLookAngle().scale(0.8)).subtract(0, 0.3, 0);
    }

    /** Punto de impacto contra bloques (o el final del rayo si no hay nada). */
    public static Vec3 blockPoint(ServerPlayer p, double range) {
        Vec3 start = p.getEyePosition();
        Vec3 end = start.add(p.getLookAngle().scale(range));
        BlockHitResult b = p.level().clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return b.getLocation();
    }

    /** Primer ser vivo válido en la línea de mira (no atraviesa bloques). Puede ser null. */
    public static EntityHitResult entity(ServerPlayer p, double range) {
        Vec3 start = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = blockPoint(p, range);
        AABB box = p.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0);
        return ProjectileUtil.getEntityHitResult(p.level(), p, start, end, box,
                e -> e instanceof LivingEntity le && Fx.isTarget(le, p));
    }

    /** Entidad si la hay, si no el bloque apuntado. */
    public static Vec3 aimPoint(ServerPlayer p, double range) {
        EntityHitResult e = entity(p, range);
        return e != null ? e.getLocation() : blockPoint(p, range);
    }
}
