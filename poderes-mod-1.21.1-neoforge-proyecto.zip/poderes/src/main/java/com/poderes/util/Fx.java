package com.poderes.util;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Utilidades de efectos, daño y selección de objetivos. */
public final class Fx {
    private Fx() {}

    /** Mensaje de error en la action bar. Siempre devuelve false (no gasta la habilidad). */
    public static boolean fail(ServerPlayer p, String key) {
        p.displayClientMessage(Component.translatable("poderes.msg." + key).withStyle(ChatFormatting.RED), true);
        return false;
    }

    /** Objetivo válido para habilidades ofensivas: ni jugadores, ni mascotas propias, ni armor stands. */
    public static boolean isTarget(LivingEntity e, ServerPlayer p) {
        if (e == p || !e.isAlive() || e.isSpectator()) return false;
        if (e instanceof Player || e instanceof ArmorStand) return false;
        if (e instanceof TamableAnimal t && t.isOwnedBy(p)) return false;
        return true;
    }

    public static List<LivingEntity> targets(ServerLevel l, ServerPlayer p, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        return l.getEntitiesOfClass(LivingEntity.class, box,
                e -> isTarget(e, p) && e.position().distanceToSqr(c) <= r * r);
    }

    public static void magic(ServerLevel l, ServerPlayer p, LivingEntity t, float amount) {
        t.hurt(l.damageSources().indirectMagic(p, p), amount);
    }

    public static void push(LivingEntity e, Vec3 velocity) {
        e.setDeltaMovement(velocity);
        e.hurtMarked = true;
    }

    public static void sound(ServerLevel l, Vec3 pos, SoundEvent ev, float vol, float pitch) {
        l.playSound(null, pos.x, pos.y, pos.z, ev, SoundSource.PLAYERS, vol, pitch);
    }

    public static void burst(ServerLevel l, ParticleOptions part, Vec3 c, int n, double spread) {
        l.sendParticles(part, c.x, c.y, c.z, n, spread, spread, spread, 0.02);
    }

    public static void line(ServerLevel l, Vec3 a, Vec3 b, ParticleOptions part) {
        double len = a.distanceTo(b);
        if (len < 0.01) return;
        Vec3 d = b.subtract(a).normalize();
        for (double i = 0; i < len; i += 0.5) {
            Vec3 q = a.add(d.scale(i));
            l.sendParticles(part, q.x, q.y, q.z, 1, 0, 0, 0, 0);
        }
    }

    public static void ring(ServerLevel l, ParticleOptions part, Vec3 c, double r, int n) {
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            l.sendParticles(part, c.x + Math.cos(a) * r, c.y, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }
}
