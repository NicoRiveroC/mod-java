package com.poderes.item;

import com.poderes.Poderes;
import com.poderes.power.Ability;
import com.poderes.power.Power;
import com.poderes.util.Fx;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Bastón de poder.
 *  - Clic derecho: usa la habilidad seleccionada.
 *  - Agachado + clic derecho: cambia de habilidad.
 * La habilidad elegida y los cooldowns (por habilidad) viven en el componente CUSTOM_DATA del ItemStack.
 */
public class PowerStaffItem extends Item {
    private final Power power;

    public PowerStaffItem(Power power, Properties properties) {
        super(properties);
        this.power = power;
    }

    public Power power() {
        return power;
    }

    private CompoundTag data(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
    }

    private int selected(ItemStack stack) {
        int i = data(stack).getInt("ability");
        return (i < 0 || i >= power.abilities().size()) ? 0 : i;
    }

    private Component abilityName(int index) {
        return Component.translatable("ability." + Poderes.MODID + "." + power.id() + "."
                + power.abilities().get(index).id());
    }

    private Style color() {
        return Style.EMPTY.withColor(power.color());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        List<Ability> abilities = power.abilities();
        int idx = selected(stack);

        // --- Cambiar de habilidad ---
        if (sp.isShiftKeyDown()) {
            final int next = (idx + 1) % abilities.size();
            CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putInt("ability", next));
            MutableComponent msg = Component.translatable("poderes.msg.selected", abilityName(next)).withStyle(color());
            sp.displayClientMessage(msg, true);
            Fx.sound(sl, sp.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 0.8f, 1.2f);
            return InteractionResultHolder.sidedSuccess(stack, false);
        }

        // --- Cooldown por habilidad ---
        Ability ab = abilities.get(idx);
        long now = sl.getGameTime();
        long ready = data(stack).getLong("cd" + idx);
        if (now < ready) {
            long secs = (long) Math.ceil((ready - now) / 20.0);
            sp.displayClientMessage(Component.translatable("poderes.msg.cooldown", abilityName(idx), secs)
                    .withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }

        // --- Ejecutar ---
        boolean ok = ab.exec().run(sl, sp);
        if (!ok) {
            return InteractionResultHolder.fail(stack);
        }
        final String key = "cd" + idx;
        final long until = now + ab.cooldownTicks();
        CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putLong(key, until));
        EquipmentSlot slot = hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND;
        stack.hurtAndBreak(ab.durabilityCost(), sp, slot); // al final: el ítem puede romperse
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tips, TooltipFlag flag) {
        int sel = selected(stack);
        tips.add(Component.translatable("poderes.tooltip.use").withStyle(ChatFormatting.GRAY));
        tips.add(Component.translatable("poderes.tooltip.cycle").withStyle(ChatFormatting.GRAY));
        tips.add(Component.empty());
        for (int i = 0; i < power.abilities().size(); i++) {
            MutableComponent line = Component.literal(i == sel ? "> " : "  ").append(abilityName(i));
            tips.add(line.withStyle(i == sel ? color() : Style.EMPTY.withColor(ChatFormatting.DARK_GRAY)));
        }
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public boolean isValidRepairItem(ItemStack toRepair, ItemStack repair) {
        return repair.is(Items.AMETHYST_SHARD);
    }

    // Evita la animación de "re-equipar" cuando solo cambia la habilidad/cooldown (datos del ítem).
    // (Sin @Override a propósito: si la firma de NeoForge cambiara, el mod sigue compilando.)
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || !oldStack.is(newStack.getItem());
    }
}
